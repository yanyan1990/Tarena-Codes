package day02;

import java.sql.Connection;

public class JDBCDemo8 {

	public static void main(String[] args) {

		Thread t1 = Thread.currentThread();
		try{
			Connection conn = DBUtil.getConnection();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBUtil.closeConnection();
		}
	}

}
