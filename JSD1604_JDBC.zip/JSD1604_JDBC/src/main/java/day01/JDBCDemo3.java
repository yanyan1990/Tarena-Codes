package day01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * ����һ������seq_userinfo_id
 * ���д�1��ʼ������Ϊ1
 * 
 * CREATE SEQUENCE seq_userinfo_id
 * START WITH 1
 * INCREMENT BY 1
 * @author Administrator
 *
 */
public class JDBCDemo3 {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.201.209:1521:orcl",
					"openlab","open123");
			Statement state = conn.createStatement();
			String sql = "CREATE SEQUENCE seq_userinfo_id  "+
                         "START WITH 1  "+
                         "INCREMENT BY 1  ";
			System.out.println(sql);
			state.execute(sql);
			System.out.println("���д�����ϣ�");
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
