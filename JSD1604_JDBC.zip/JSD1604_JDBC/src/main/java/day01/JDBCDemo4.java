package day01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * �鿴ÿ��Ա���Ĺ��ţ����֣�ְλ��нˮ�����źţ����������Լ��������ڵ�
 * @author Administrator
 *
 */
public class JDBCDemo4 {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.201.209:1521:orcl",
					"openlab","open123");
			Statement state = conn.createStatement();
			String sql = "SELECT empno, ename, job, sal, emp.deptno, dname, loc "+
			             "FROM emp, dept WHERE emp.deptno=dept.deptno";
			ResultSet rs = state.executeQuery(sql);
			while(rs.next()){
				int empno = rs.getInt("empno");
				String ename = rs.getString("ename");
				String job = rs.getString("job");
				int sal = rs.getInt("sal");
				int deptno = rs.getInt("deptno");
				String dname = rs.getString("dname");
				String loc = rs.getString("loc");
				System.out.println(empno+","+ename+","+job+","+sal+","
				+deptno+","+dname+","+loc);
			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
}
