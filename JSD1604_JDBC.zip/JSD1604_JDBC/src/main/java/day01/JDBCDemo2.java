package day01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * ִ��DDL���
 * ������userinfo
 * ���е��ֶΣ�
 * id NUMBER(5)
 * username VARCHAR2(40)
 * password VARCHAR2(40)
 * account NUMBER(8)          �˻����
 * email VARCHAR2(100)
 * @author Administrator
 *
 */
public class JDBCDemo2 {

	public static void main(String[] args) {

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.201.209:1521:orcl",
					"openlab","open123");
			Statement state = conn.createStatement();
			//
			String sql = "CREATE TABLE userinfo ("+
			             "   id NUMBER(5),  "+
					     "   username VARCHAR2(40),  "+
			             "   password VARCHAR2(40),  "+
					     "   account NUMBER(8),  "+
			             "   email VARCHAR2(100)  "+
					     ")";
			state.execute(sql);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
