package com.tedu.controller;

import java.util.ArrayList;
import java.util.List;

import com.tedu.entity.User;

@Controller    //ɨ�赽Spring����
@RequestMapping("/ajax")
public class AjaxController {
	
	@RequestMapping("/load2.do")
	@ResponseBody
	public List<User> load2(){
		List<User> list = new ArrayList<User>();
		User user1 = new User();
		user1.setId(1);
		user1.setName("��ү");
		list.add(user1);
		User user2 = new User();
		user2.setId(2);
		user2.setName("��ү");
		list.add(user2);
		return list;
	}
	
	@RequestMapping("/load1.do")
	@ResponseBody    //��Userת��JSON���
	public User load1(){
		User user = new User();
		user.setId(1);
		user.setName("����");
		return user;
	}
}
