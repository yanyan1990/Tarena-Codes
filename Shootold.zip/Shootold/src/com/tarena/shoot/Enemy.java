package com.tarena.shoot;

public interface Enemy {
	public int getScore();
}
