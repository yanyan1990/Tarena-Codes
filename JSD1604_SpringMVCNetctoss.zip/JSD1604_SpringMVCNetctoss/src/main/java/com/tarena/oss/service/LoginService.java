package com.tarena.oss.service;

import com.tarena.oss.entity.Admin;

/**
 * ҵ��ӿ�
 * @author Administrator
 *
 */
public interface LoginService {
	public Admin checkLogin(String adminCode, String pwd);
}
