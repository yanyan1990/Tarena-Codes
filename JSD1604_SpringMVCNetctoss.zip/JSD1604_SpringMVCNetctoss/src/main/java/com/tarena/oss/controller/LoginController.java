package com.tarena.oss.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.tarena.oss.entity.Admin;
import com.tarena.oss.service.LoginService;
import com.tarena.oss.util.ApplicationException;

/**
 * �������ࣨ������������
 * @author Administrator
 *
 */
@Controller
public class LoginController {
	@Resource(name="loginService")
	private LoginService service;
	@RequestMapping("/toLogin.do")
	public String toLogin(){
		return "login";
	}
	
	@RequestMapping("/login.do")
	public String login(HttpServletRequest request,
			HttpSession session){
		/*
		 * ��ȡ�ʺź�����
		 */
		String adminCode = request.getParameter("adminCode");
		String pwd = request.getParameter("pwd");
		System.out.println("adminCode:"+adminCode+" pwd:"+pwd);
		/*
		 * ����ҵ��������������¼
		 */
		try{
			Admin admin = service.checkLogin(adminCode, pwd);
			/*
			 * ��¼�ɹ�֮�󣬰�һЩ���ݵ�session������
			 */
			session.setAttribute("admin", admin);
		}catch(Exception e){
			e.printStackTrace();
			if(e instanceof ApplicationException){
				/*
				 * Ӧ���쳣
				 */
				request.setAttribute("login_failed", e.getMessage());
				return "login";
			}
			/*
			 * ϵͳ�쳣
			 */
			return "error";
		}
		/*
		 * ��¼�ɹ�
		 */
		return "redirect:toIndex.do";
	}
	
	@RequestMapping("/toIndex.do")
	public String toIndex(){
		return "index";
	}
	
}
