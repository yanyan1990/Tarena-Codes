package test;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.catalina.core.ApplicationContext;

import com.tarena.oss.dao.AdminDAO;
import com.tarena.oss.entity.Admin;
import com.tarena.oss.service.LoginService;

public class TestCase {

	/*
	 * ����DataSource
	 */
	@Test
	public void test1(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"spring-mvc.xml");
		DataSource ds = (DataSource)ac.getBean("dataSource");
		Connection conn = ds.getConnection();
		System.out.println(conn);
	}
	
	/*
	 * ����DAO
	 */
	@Test
	public void test2(){
		String conf = "spring-mvc.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(conf);
		AdminDAO dao = ctx.getBean("adminDAO",AdminDAO.class);
		Admin admin = dao.findByAdminCode("caocao");
		System.out.println(admin);
	}
	
	/*
	 * ����Service
	 */
	@Test
	public void test3() throws SQLException{
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"spring-mvc.xml");
		LoginService service = ac.getBean("loginService",LoginService.class);
		Admin admin = service.checkLogin("caocao", "123");
		System.out.println(admin);
	}
}
