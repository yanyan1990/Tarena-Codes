package com.tedu.cloudnote.controller.note;

import javax.annotation.Resource;

import com.tedu.cloudnote.service.NoteService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
public class UpdateNoteController {
	@Resource
	private NoteService noteService;
	@RequestMapping("/note/update.do")
	@ResponseBody
	public NoteResult execute(String noteId, String title, String body){
		NoteResult result = noteService.updateNote(noteId, title, body);
		return result;
	}
}
