package com.tedu.cloudnote.controller.user;

import javax.annotation.Resource;

import com.tedu.cloudnote.service.UserService;
import com.tedu.cloudnote.util.NoteResult;

@Controller      //ɨ��
public class UserLoginController {

	@Resource    //ע��
	private UserService userService;
	@RequestMapping("/user/login.do")
	@ResponseBody     //JSON���
	public NoteResult execute(String name, String password){
		/*
		 * ����UserService������¼
		 */
		NoteResult result = userService.checkLogin(name, password);
		return result;
	}
}
