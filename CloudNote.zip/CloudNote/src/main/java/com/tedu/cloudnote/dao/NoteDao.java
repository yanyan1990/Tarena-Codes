package com.tedu.cloudnote.dao;

import java.util.List;
import java.util.Map;

import com.tedu.cloudnote.entity.Note;


public interface NoteDao {

	public List<Map> findByBookId(String bookId);
	public Note findById(String noteId);
	public int updateNote(Note note);
}
