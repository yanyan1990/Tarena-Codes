package com.tedu.cloudnote.controller.note;

import javax.annotation.Resource;

import com.tedu.cloudnote.service.NoteService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
public class LoadNoteController {
	@Resource
	private NoteService noteService;
	@RequestMapping("/note/load.do")
	@ResponseBody
	public NoteResult execute(String noteId){
		NoteResult result = noteService.loadNote(noteId);
		return result;
	}
}
