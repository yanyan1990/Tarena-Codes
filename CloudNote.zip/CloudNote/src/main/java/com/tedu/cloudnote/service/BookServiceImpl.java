package com.tedu.cloudnote.service;

import java.util.List;

import com.tedu.cloudnote.dao.BookDao;
import com.tedu.cloudnote.entity.Book;
import com.tedu.cloudnote.util.NoteResult;

@Service("bookService")
public class BookServiceImpl implements BookService{

	@Resource
	private BookDao bookDao;
	public NoteResult loadUserBooks(String userId) {
		/*
		 * ���û�ID��ѯ�ʼǱ���Ϣ
		 */
		List<Book> list = bookDao.findByUserId(userId);
		/*
		 * �������ؽ��
		 */
		NoteResult result = new NoteResult();
		result.setStatus(0);
		result.setMsg("��ѯ���");
		result.setData(list);
		return null;
	}

}
