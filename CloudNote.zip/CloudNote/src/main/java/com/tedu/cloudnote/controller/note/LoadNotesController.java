package com.tedu.cloudnote.controller.note;

import javax.annotation.Resource;

import com.tedu.cloudnote.service.NoteService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
public class LoadNotesController {

	@Resource
	private NoteService noteService;
	@RequestMapping("/note/loadnotes.do")
	@ResponseBody
	public NoteResult execute(String bookId){
		NoteResult result = noteService.loadBookNotes(bookId);
		return result;
	}
}
