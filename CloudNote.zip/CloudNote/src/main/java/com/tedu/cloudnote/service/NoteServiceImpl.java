package com.tedu.cloudnote.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.tedu.cloudnote.dao.NoteDao;
import com.tedu.cloudnote.entity.Note;
import com.tedu.cloudnote.util.NoteResult;

@Service("noteService")
public class NoteServiceImpl implements NoteService{
	@Resource
	private NoteDao noteDao;
	public NoteResult loadBookNotes(String bookId) {
		/*
		 * ���ʼǱ�ID��ѯ�ʼ���Ϣ
		 */
		List<Map> list = noteDao.findByBookId(bookId);
		/*
		 * �������ؽ��
		 */
		NoteResult result = new NoteResult();
		result.setStatus(0);
		result.setMsg("��ѯ���");
		result.setData(list);
		return result;
	}
	public NoteResult loadNote(String noteId) {
		/*
		 * ���ʼ�ID��ѯ�ʼ���Ϣ
		 */
		Note note = noteDao.findById(noteId);
		/*
		 * �������ؽ��
		 */
		NoteResult result = new NoteResult();
		result.setStatus(0);
		result.setMsg("��ѯ���");
		result.setData(note);
		return null;
	}
	public NoteResult updateNote(String noteId, String title, String body) {
		Note note = new Note();
		note.setCn_note_id(noteId);
		note.setCn_note_title(title);
		note.setCn_note_body(body);
		Long time = System.currentTimeMillis();
		note.setCn_note_last_modify_time(time);
		int rows = noteDao.updateNote(note);
		NoteResult result = new NoteResult();
		if(rows == 1){    //�ɹ�
			result.setStatus(0);
			result.setMsg("����ʼǳɹ�");
		}else{            //ʧ��
			result.setStatus(1);
			result.setMsg("����ʼ�ʧ��");
		}
		return null;
	}

}
