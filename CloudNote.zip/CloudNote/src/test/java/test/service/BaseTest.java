package test.service;

import org.apache.catalina.core.ApplicationContext;

public class BaseTest {

	ApplicationContext ac;
	@Before
	public void init(){
		String[] conf = {"conf/spring-mvc.xml","conf/spring-mybatis.xml"};
		ac = new ClassPathXmlApplicationContext(conf);
	}
}
