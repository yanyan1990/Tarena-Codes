package controller;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HelloController {

	@ExceptionHandler
	public String handler(Exception ex, HttpServletRequest request){
		/*
		 * �����쳣���ͣ����в�ͬ�Ĵ���
		 */
		if(ex instanceof NumberFormatException){
			request.setAttribute("msg", "�ף���������ȷ������");
			return "message";
		}else if(e instanceof StringIndexOutOfBoundsException){
			request.setAttribute("msg", "����Խ��");
			return "message";
		}
		return "error3";
	}
	
	@RequestMapping("/hello.do")
	public String hello(){
		System.out.println("hello()...");
		String str = "123a";
		Integer.parseInt(str);
		return "hello";
	}
	
	@RequestMapping("/hello2.do")
	public String hello2(){
		System.out.println("hello2()...");
		String str = "abcd";
		str.charAt(10);
		return "hello";
	}
}
