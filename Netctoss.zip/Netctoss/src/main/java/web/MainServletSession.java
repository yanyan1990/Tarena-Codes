package web;

/**
 * Session��
 */
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AdminDao;
import dao.CostDao;
import entity.Admin;
import entity.Cost;

public class MainServletSession extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		if("/findCost.do".equals(path)){
			/*
			 * ��ѯ�����ʷ�
			 */
			findCost(request,response);
		}else if("/toAddCost.do".equals(path)){
			/*
			 * �������ʷ�ҳ
			 */
			toAddCost(request,response);
		}else if("/addCost.do".equals(path)){
			/*
			 * �����ʷ�
			 */
			addCost(request,response);
		}else if("/toUpdateCost.do".equals(path)){
			/*
			 * ���޸��ʷ�ҳ
			 */
			toUpdateCost(request,response);
		}else if("/toLogin.do".equals(path)){
			/*
			 * �򿪵�¼ҳ��
			 */
			toLogin(request,response);
		}else if("/toIndex.do".equals(path)){
			/*
			 * ����ҳ
			 */
			toIndex(request,response);
		}else if("/login.do".equals(path)){
			/*
			 * ��¼
			 */
			login(request,response);
		}
		else{
		
			throw new RuntimeException("��Ч�ķ���·����");
		}
	}
	
	protected void findCost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*
		 * ��ѯ���е��ʷ�
		 */
		CostDao dao = new CostDao();
		List<Cost> list = dao.findAll();
		/*
		 * ת������ѯҳ��
		 * ��ǰ·����/Netctoss/findCost.do
		 * Ŀ��·����/Netctoss/WEB-INF/cost/find.jsp
		 */
		request.setAttribute("costs", list);
		request.getRequestDispatcher("WEB-INF/cost/find.jsp").forward(request, response);
		
	}
	
	protected void toAddCost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * ת��������ҳ��
		 * ��ǰ·����/Netctoss/toAddCost.do
		 * Ŀ��·����/Netctoss/WEB-INF/cost/add.jsp
		 */
		request.getRequestDispatcher("WEB-INF/cost/add.jsp").forward(request, response);
		
	}
	
	protected void addCost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		/*
		 * ���ձ�������
		 */
		String name = request.getParameter("name");
		String baseDuration = request.getParameter("baseDuration");
		String baseCost = request.getParameter("baseCost");
		String unitCost = request.getParameter("unitCost");
		String description = request.getParameter("description");
		String costType = request.getParameter("costType");
		/*
		 * �洢����
		 */
		Cost cost = new Cost();
		cost.setName(name);
		if(baseDuration != null && !baseDuration.equals("")){
			cost.setBaseDuration(new Integer(baseDuration));
		}
		if(baseCost != null && !baseCost.equals("")){
			cost.setBaseCost(new Double(baseCost));
		}
		if(unitCost != null && !unitCost.equals("")){
			cost.setUnitCost(new Double(unitCost));
		}
		cost.setDescription(description);
		cost.setCostType(costType);
		CostDao dao = new CostDao();
		dao.save(cost);
		/*
		 * �ض��򵽲�ѯ����
		 * ��ǰ·����/Netctoss/addCost.do
		 * Ŀ��·����/Netctoss/findCost.do
		 */
		response.sendRedirect("findCost.do");
	}
	
	protected void toUpdateCost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * ���մ���Ĳ���
		 */
		String id = request.getParameter("id");
		/*
		 * ��ѯҪ�޸ĵ�����
		 */
		CostDao dao = new CostDao();
		Cost cost = dao.findById(new Integer(id));
		/*
		 * ת�����޸�ҳ��
		 */
		request.setAttribute("cost", cost);
		request.getRequestDispatcher("WEB-INF/cost/update.jsp").forward(request, response);
	}
	
	protected void toLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("WEB-INF/main/login.jsp").forward(request, response);
	}
	
	protected void toIndex(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("WEB-INF/main/index.jsp").forward(request, response);
	}
	
	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * ���ձ�������
		 */
		String adminCode = request.getParameter("adminCode");
		String password = request.getParameter("password");
		/*
		 * ��֤�ʺ�����
		 */
		AdminDao dao = new AdminDao();
		Admin admin = dao.findByCode(adminCode);
		if(admin == null){
			/*
			 * �ʺŴ���ת������¼ҳ
			 */
			request.setAttribute("error", "�ʺŴ���");
			request.getRequestDispatcher("WEB-INF/main/login.jsp").forward(request, response);
		} else if(!admin.getPassword().equals(password)){
			/*
			 * �������ת������¼ҳ
			 */
			request.setAttribute("error", "�������");
			request.getRequestDispatcher("WEB-INF/main/login.jsp").forward(request, response);
		} else {
			/*
			 * ���ʺŴ���session
			 */
			HttpSession session = request.getSession();
			session.setAttribute("adminCode", adminCode);
			/*
			 * ��¼�ɹ����ض�����ҳ
			 */
			response.sendRedirect("toIndex.do");
		}
	}
}

