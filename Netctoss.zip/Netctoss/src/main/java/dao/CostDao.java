package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Cost;
import util.DBUtil;

public class CostDao {

	public List<Cost> findAll(){
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select * from cost order by cost_id";
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			List<Cost> list = new ArrayList<Cost>();
			while(rs.next()){
				Cost cost = createCost(rs);
				list.add(cost);
			}
			return list;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("��ѯ�ʷ�ʧ��",e);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ѯ�ʷ�ʧ��",e);
		}finally{
			DBUtil.closeConnection();
		}
	}

	/**
	 * Alt+Shift+M
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Cost createCost(ResultSet rs) throws SQLException {
		Cost cost = new Cost();
		cost.setCostId(rs.getInt("cost_id"));
		cost.setName(rs.getString("name"));
		cost.setBaseDuration(rs.getInt("base_duration"));
		cost.setBaseCost(rs.getDouble("base_cost"));
		cost.setUnitCost(rs.getDouble("unit_cost"));
		cost.setStatus(rs.getString("status"));
		cost.setDescription(rs.getString("description"));
		cost.setCreatime(rs.getTimestamp("creatime"));
		cost.setStartime(rs.getTimestamp("startime"));
		cost.setCostType(rs.getString("cost_type"));
		return cost;
	}
	
	public void save(Cost cost){
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "insert into cost values(cost_seq.nextval,"
					+ "?,?,?,?,'1',?,sysdate,null,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cost.getName());
			/*
			 * �ڵ�ǰҵ���£�����ʱ�����������á���λ���ö�����Ϊnull���ֶ�Ҳ������null��
			 * ��setInt/setDouble��������������null�����Խ����������ݵ���Object������
			 */
			ps.setObject(2, cost.getBaseDuration());
			ps.setObject(3, cost.getBaseCost());
			ps.setObject(4, cost.getUnitCost());
			ps.setString(5, cost.getDescription());
			ps.setString(6, cost.getCostType());
			ps.executeUpdate();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("�����ʷ�ʧ��",e);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("�����ʷ�ʧ��",e);
		} finally {
			DBUtil.closeConnection();
		}
	}
	
	public Cost findById(int id){
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select * from cost where cost_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				return createCost(rs);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("��ѯ�ʷ�ʧ��",e);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ѯ�ʷ�ʧ��",e);
		} finally {
			DBUtil.closeConnection();
		}
		return null;
	}
	
	public static void main(String[] args){
		CostDao dao = new CostDao();
//		��ѯ����
//		List<Cost> list = dao.findAll();
//		for(Cost cost : list){
//			System.out.println(
//				cost.getCostId()+","+
//					cost.getName()+","+
//						cost.getDescription());
//		}
		
//		���Ӳ���
		Cost cost = new Cost();
		cost.setName("Tarena�ײ�");
		cost.setBaseDuration(600);
		cost.setBaseCost(60.0);
		cost.setUnitCost(0.6);
		cost.setDescription("Tarena�ײͲ���");
		cost.setCostType("2");
		dao.save(cost);
	}
}
