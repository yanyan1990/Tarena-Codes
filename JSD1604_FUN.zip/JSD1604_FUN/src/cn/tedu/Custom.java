package cn.tedu;

import java.util.Arrays;

public class Custom {

	public static void main(String[] args) {
		int[] array1={1,2,3,4,5,6,7,8};
		int[] array2={20,30,40};
		Arrays.copyOf(array1, array1.length+2);
		System.arraycopy(array2, 1, array1, 3, 2);
		for(int i=0;i<array1.length;i++){
			System.out.print(array1[i]+",");
		}
		System.out.println();
	}

}
