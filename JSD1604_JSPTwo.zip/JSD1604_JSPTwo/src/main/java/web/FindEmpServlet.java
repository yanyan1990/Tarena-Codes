package web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import entity.Emp;

public class FindEmpServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * ��ѯ���е�Ա��
		 */
		EmpDao dao = new EmpDao();
		List<Emp> list = dao.findAll();
		/*
		 * ת����JSP
		 */
		/*
		 * 1.�����ݰ���request��
		 */
		request.setAttribute("emps",list);
		/*
		 * 2.������ת����JSP
		 */
		/*
		 * ��ǰ·����/JSD1604_JSPTwo/findEmp
		 * Ŀ��·����/JSD1604_JSPTwo/emp_list.jsp
		 */
		request.getRequestDispatcher("emp_list.jsp").forward(request, response);
	}

}
