package com.terana;

public class HelloAction {

	private String message;
	public String getMessage(){
		return message;
	}
	/**
	 * ������������execute
	 * @return
	 */
	public String execute(){
		message = "Hi";
		System.out.println("Hello World!");
		return "success";
	}
}
