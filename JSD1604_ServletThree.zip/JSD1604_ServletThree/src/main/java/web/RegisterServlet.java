package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.������������
		 */
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("userName");
		String password = request.getParameter("password");
		String sex = request.getParameter("sex");
		String[] interests = request.getParameterValues("interest");
//		name = new String(name.getBytes("ISO-8859-1"),"UTF-8");
		/*
		 * 2.����ҵ��
		 */
		System.out.println(name);
		System.out.println(password);
		System.out.println(sex);
		if(interests != null){
			for(String interest : interests){
				System.out.println(interest);
			}
		}
		/*
		 * 3.������Ӧ����
		 */
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<p>ע��ɹ�</p>");
		out.close();
	}

}
