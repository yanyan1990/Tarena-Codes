package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Course;
import entity.Student;

public class DemoServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * ģ���ѯѧ������
		 */
		Student student = new Student();
		student.setName("cang");
		student.setAge(18);
		student.setSex("F");
		student.setInterests(new String[]{"����","��Ƭ","��"});
		Course course = new Course();
		course.setId(1);
		course.setCourseName("Java");
		course.setDays(80);
		student.setCourse(course);
		/*
		 * ת����JSP
		 * ��ǰ·����/JSD1604_JSPThree/demo
		 * Ŀ��·����/JSD1604_JSPThree/demo.jsp
		 */
		request.setAttribute("stu", student);
		request.getRequestDispatcher("demo.jsp").forward(request, response);
		
	}

	
}
