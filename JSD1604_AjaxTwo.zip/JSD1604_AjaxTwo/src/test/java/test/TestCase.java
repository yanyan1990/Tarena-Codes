package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Test;

import bean.Stock;

public class TestCase {

	/*
	 * ��java����ת����json�ַ���
	 */
	@Test
	public void test1(){
		Stock stock = new Stock();
		stock.setCode("600015");
		stock.setName("ɽ������");
		stock.setPrice(10);
		JSONObject jo = JSONObject.fromObject(stock);
		String json = jo.toString();
		System.out.println(json);
	}
	
	@Test
	public void test2(){
		List<Stock> stocks = new ArrayList<Stock>();
		Random random = new Random();
		for(int i = 0; i < 8; i++){
			Stock s = new Stock();
			s.setCode("60001"+(i+1));
			s.setName("ɽ������"+i);
			s.setPrice(random.nextInt(100));
			stocks.add(s);
		}
		/*
		 * fromObject���Խ����������List
		 */
		JSONArray jsa = JSONArray.fromObject(stocks);
		String json = jsa.toString();
		System.out.println(json);
		
	}
}
