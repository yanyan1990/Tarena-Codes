function getXmlHttpRequest() {
	var xhr = null;
	if (window.XMLHttpRequest) { // ��IE�����
		xhr = new XMLHttpRequest();
	} else { // IE�����
		xhr = new ActiveXObject('Microsoft.XMLHttp');
	}
	return xhr;
}

function $(id){
	return document.getElementById(id);
}

function $F(id){
	return $(id).value;
}
