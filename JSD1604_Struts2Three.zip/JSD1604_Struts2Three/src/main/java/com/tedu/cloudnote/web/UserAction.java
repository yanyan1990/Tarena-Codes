package com.tedu.cloudnote.web;

import java.util.List;
import java.util.Map;

import com.tedu.cloudnote.entity.User;
import com.tedu.cloudnote.service.UserService;
import com.tedu.cloudnote.util.NoteResult;

@Controller
@Scope("request")  //ActionΪ���̰߳�ȫ����Ҫ����������һ�δ���һ��������Ҫ�Ӳ���"request"
public class UserAction extends BaseAction{
	@Resource
	private UserService userService;
	private String username;
	private String password;
	private NoteResult result;
	private Map<String, Object> session;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public NoteResult getResult(){
		return result;
	}
	
	public Map<String, Object> getSession() {
		return session;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setResult(NoteResult result) {
		this.result = result;
	}

	public String login(){
		NoteResult result = userService.checkLogin(username, password);
		this.result = result;
		if(result.getStatus() == 0){
			User user = (User)result.getData();
			session.put("loginUser",user);
			return "success";
		}
	}
	
	private List<Map<String, Object>> list;
	
	public List<Map<String, Object>> getList() {
		return list;
	}

	public void setList(List<Map<String, Object>> list) {
		this.list = list;
	}

	public String list(){
		try{
			list = userService.findAll();
			return SUCCESS;
		}catch(Exception e){
			e.printStackTrace();
			return ERROR;
		}
	}
}
