package com.tedu.cloudnote.dao;

import com.tedu.cloudnote.entity.Emp;

public interface EmpDao {

	public void save(Emp emp);
}
