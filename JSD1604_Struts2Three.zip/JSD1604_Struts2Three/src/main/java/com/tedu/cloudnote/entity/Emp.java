package com.tedu.cloudnote.entity;

import java.io.Serializable;

public class Emp implements Serializable{

	private int no;
	private String name;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Emp [id=" + no + ", name=" + name + "]";
	}
	
}
