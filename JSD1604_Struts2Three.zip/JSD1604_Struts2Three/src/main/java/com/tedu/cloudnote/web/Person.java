package com.tedu.cloudnote.web;

public class Person {
	private int id;
	private String pname;
	private String message;
	public Person() {
		
	}
	public Person(int id, String pname, String message) {
		super();
		this.id = id;
		this.pname = pname;
		this.message = message;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", pname=" + pname + ", message=" + message + "]";
	}
	
}
