package com.tedu.cloudnote.web;

import java.util.Map;

@Controller
public class DemoAction {
	String message;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String test(){
		ActionContext context = ActionContext.getContext();
		ValueStack stack = context.getValueStack();
		Map<String, Object> map = new Map<String, Object>();
		map.put("name","Tom");
		map.put("age",100);
		map.put("message","I am Tom.");
		//��map���ӵ�stack
		stack.push(map);
		Person person = new Person(1, "Jerry", "Hello Jerry");
		stack.push(person);
		context.getSession().put("loginName","Robin");
		message = "demo";
		System.out.println("Demo Action Test()");
		return "success";
	}
}
