package com.tedu.test;

import com.tedu.note.dao.UserDao;
import com.tedu.note.entity.User;
import com.tedu.note.service.UserService;

public class TestCase {
	ApplicationContext ctx;
	@Before
	public void init(){
		ctx = new ClassPathXmlApplicationContext("spring-context.xml");
	}
	
	@Test
	public void testFindByName(){
		UserDao dao = ctx.getBean("UserDao",UserDao.class);
		User user = dao.findByName("tedu");
		System.out.println(user);
	}
	
	@Test
	public void testLogin(){
		String username = "tedu";
		String password = "123456";
		UserService service = ctx.getBean("userService",UserService.class);
		try{
			User user = service.login(username, password);
			System.out.println(user);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
}
