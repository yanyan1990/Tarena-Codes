package com.tedu.note.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {

	public static String md5(String str){
		try {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			byte[] data = str.getBytes("utf-8");
			byte[] md5 = digest.digest(data);
			return Base64.encodeBase64String(md5);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public MD5Util() {
	}
	
}
