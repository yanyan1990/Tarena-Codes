package com.tedu.note.web;

import com.tedu.note.entity.User;
import com.tedu.note.util.Result;

@Controller
@Scope("prototype")
public class UserAction extends BaseAction{
	private String username;
	private String password;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * ��¼Action
	 */
	public String login(){
		try{
			User loginUser = userService.login(username, password);
			session.put("loginUser", loginUser);
			//�ɹ����ص�¼�û���Ϣ
			result = new Result<User>(loginUser);
		}catch (Exception e){
			e.printStackTrace();
			//ʧ��
			result = new Result(e);
		}
		return SUCCESS;
	}
	
	public String list(){
		try{
			list = userService.list();
			return SUCCESS;
		}catch(Exception e){
			e.printStackTrace();
			return ERROR;
		}
	}
}
