package com.tedu.note.web;

import java.io.Serializable;
import java.util.Map;

import com.tedu.note.service.UserService;
import com.tedu.note.util.Result;

public abstract class BaseAction extends ActionSupport 
	implements Serializable, RequestAware, SessionAware, ApplicationAware{

	protected Map<String, Object> request;
	protected Map<String, Object> session;
	protected Map<String, Object> application;
	
	public Map<String, Object> getRequest() {
		return request;
	}
	public void setRequest(Map<String, Object> request) {
		this.request = request;
	}
	public Map<String, Object> getSession() {
		return session;
	}
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	public Map<String, Object> getApplication() {
		return application;
	}
	public void setApplication(Map<String, Object> application) {
		this.application = application;
	}
	
	@Autowired
	protected UserService userService;
	/**
	 * Json����ֵ
	 */
	protected Result result;
	public Result getResult(){
		return result;
	}
}
