package com.tedu.note.util;

import java.io.Serializable;

public class Result<T> implements Serializable{

	public static final int SUCCESS = 0;
	public static final int ERROR = 1;
	private int state = SUCCESS;
	private String message = "";
	private T data;
	
	public Result(){
		
	}
	public Result(Exception e){
		state = ERROR;
		message = e.getMessage();
	}
	public Result(T data){
		state = SUCCESS;
		message = "SUCCESS";
		this.data = data;
	}
	public Result(String message){
		state = SUCCESS;
		this.message = message;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "Result [state=" + state + ", message=" + message + ", data=" + data + "]";
	}
	
}
