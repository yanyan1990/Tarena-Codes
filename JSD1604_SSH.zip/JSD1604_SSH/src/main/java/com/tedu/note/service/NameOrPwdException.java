package com.tedu.note.service;

public class NameOrPwdException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NameOrPwdException() {
	}

	public NameOrPwdException(String message) {
		super(message);
	}

	public NameOrPwdException(Throwable cause) {
		super(cause);
	}

	public NameOrPwdException(String message, Throwable cause) {
		super(message, cause);
	}

	public NameOrPwdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
