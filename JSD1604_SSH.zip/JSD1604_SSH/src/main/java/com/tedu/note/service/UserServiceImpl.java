package com.tedu.note.service;

import java.util.List;

import com.tedu.note.dao.UserDao;
import com.tedu.note.entity.User;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;
	
	public UserServiceImpl() {
	}

	public User login(String username, String password) throws NameOrPwdException {
		if(username == null || username.trim().isEmpty()){
			throw new NameOrPwdException("�û������ܿ�");
		}
		if(username.length()>20){
			throw new NameOrPwdException("�û���̫����");
		}
		if(password == null || password.trim().isEmpty()){
			throw new NameOrPwdException("���벻��Ϊ��");
		}
		User someone = userDao.findByName(username);
		if(someone == null){
			throw new NameOrPwdException("�û������������");
		}
		String pwd = MD5Util.md5(password);
		if(someone.getPassword().equals(pwd)){
			return someone;
		}
		throw new NameOrPwdException("�û������������");
	}

	public List<User> list() {
		return userDao.findAll();
	}

}
