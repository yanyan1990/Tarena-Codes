package com.tedu.note.dao;

import java.util.List;
import java.util.UUID;

import com.tedu.note.entity.User;

@Repository("userDao")
@Transactional
public class HibernateUserDao implements UserDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public void save(User user) {
		if(user.getId() == null){
			String id = UUID.randomUUID().toString();
			user.setId(id);
		}
		hibernateTemplate.save(user);
	}

	public void delete(User user) {
		hibernateTemplate.delete(user);
	}

	public void update(User user) {
		hibernateTemplate.update(user);
	}

	public User findById(String id) {
		String hql = "from User where id=:id";
		List list = hibernateTemplate.find(hql,id);
		if(list.isEmpty()){
			return null;
		}else{
			return (User)list.get(0);
		}
	}

	public List<User> findAll() {
		String hql = "from User";
		List<User> list = hibernateTemplate.find(hql);
		return list;
	}

	public User findByName(String name) {
		String hql = "from User where name=:name";
		List list = hibernateTemplate.find(hql,name);
		if(list.isEmpty()){
			return null;
		}
		return (User)list.get(0);
	}

}
