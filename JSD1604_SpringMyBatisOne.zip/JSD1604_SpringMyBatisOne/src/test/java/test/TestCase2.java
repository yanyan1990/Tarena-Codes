package test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import dao.EmpDAO;
import entity.Emp;

public class TestCase2 {
	private SqlSession session;
	@Before
	public void init(){
		SqlSessionFactoryBuilder ssfb = new SqlSessionFactoryBuilder();
		SqlSessionFactory ssf = ssfb.build(TestCase.class
				.getClassLoader().getResourceAsStream("SqlMapConfig.xml"));
		/*
		 * SqlSession��ִ��sql��������
		 */
		session = ssf.openSession();
	}
	
	/*
	 * ����Mapperӳ����
	 */
	@Test
	public void test1(){
		/*
		 * getMapper�����᷵��һ��ʵ����EmpDAO�ӿ�Ҫ��Ķ���
		 */
		EmpDAO dao = session.getMapper(EmpDAO.class);
		Emp emp = new Emp();
		emp.setEname("Eric");
		emp.setAge(22);
		dao.save(emp);
		session.commit();
		session.close();
	}
	
	@Test
	public void test2(){
		EmpDAO dao = session.getMapper(EmpDAO.class);
		List<Emp> emps = dao.findAll();
		System.out.println(emps);
	}
	
	@Test
	public void test3(){
		EmpDAO dao = session.getMapper(EmpDAO.class);
		Emp emp = dao.findById(21);
		System.out.println(emp);
	}
	
	@Test
	public void test4(){
		/*
		 * ������Ϣ��������ƣ���̬����
		 */
		EmpDAO dao = session.getMapper(EmpDAO.class);
		Emp emp = dao.findById(21);
		emp.setAge(emp.getAge()*2);
		dao.modify(emp);
		session.commit();
		session.close();
		System.out.println(emp);
	}
	
	@Test
	public void test5(){
		EmpDAO dao = session.getMapper(EmpDAO.class);
		dao.delete(21);
	}
}
