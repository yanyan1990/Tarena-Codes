package test;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import entity.Emp;
import entity.Emp2;

public class TestCase {

	private SqlSession session;
	@Before
	public void init(){
		SqlSessionFactoryBuilder ssfb = new SqlSessionFactoryBuilder();
		SqlSessionFactory ssf = ssfb.build(TestCase.class
				.getClassLoader().getResourceAsStream("SqlMapConfig.xml"));
		/*
		 * SqlSession��ִ��sql��������
		 */
		session = ssf.openSession();
	}
	
	@Test
	public void test1(){
		Emp emp = new Emp();
		emp.setEname("King");
		emp.setAge(22);
		session.insert("save",emp);
		/*
		 * ���롢�޸ĺ�ɾ������������Ҫ�ύ����
		 */
		session.commit();
		/*
		 * ʹ�������رա�
		 */
		session.close();
	}
	
	@Test
	public void test2(){
		List<Emp> emps = session.selectList("findAll");
		System.out.println(emps);
	}
	
	@Test
	public void test3(){
		Emp emp = session.selectOne("findById",2);
		System.out.println(emp);
	}
	
	@Test
	public void test4(){
		Emp emp = session.selectOne("findById",2);
		emp.setAge(emp.getAge()*2);
		session.update("modify",emp);
		session.commit();
		session.close();
	}
	
	@Test
	public void test5(){
		session.delete("delete",2);
		session.commit();
		session.close();
	}
	
	@Test
	public void test6(){
		Map data = session.selectOne("findById2",21);
		/*
		 * oracle�Ὣ�ֶ�����ɴ�д��ʽ
		 */
		System.out.println(data.get("ENAME"));
		session.close();
	}
	
	@Test
	public void test7(){
		Emp2 emp2 = session.selectOne("findById3",21);
		System.out.println(emp2);
		session.close();
	}
}
