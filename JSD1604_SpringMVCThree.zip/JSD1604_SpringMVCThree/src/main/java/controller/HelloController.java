package controller;

public class HelloController {

	@RequestMapping("/hello.do")
	public String hello(){
		System.out.println("hello()...");
		return "hello";
	}
	
	@RequestMapping("/demo/hello.do")
	public String hello2(){
		System.out.println("hello2()...");
		return "hello";
	}
}
