package cs.imu.edu;

public interface Plane {
	public int getScore();
}
