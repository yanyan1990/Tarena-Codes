package com.tedu.service;

@Service
public class DemoService {
	public void hello(){
		System.out.println("Hello!");
	}
}
