package com.tedu.web;

import java.util.HashMap;
import java.util.Map;

@Controller
public class JsonAction {
	private int id;
	private String message;
	//���ڱ������û����͵�JSON����
	private Map<String, Object> value = new HashMap<String, Object>();
	
	public Map<String, Object> getValue() {
		return value;
	}

	public void setValue(Map<String, Object> value) {
		this.value = value;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "JsonAction [id=" + id + ", message=" + message + "]";
	}

	public String execute(){
		value.put("name", "Tom");
		value.put("age", 100);
		id = 100;
		message = "Hello";
		return "success";
	}
}
