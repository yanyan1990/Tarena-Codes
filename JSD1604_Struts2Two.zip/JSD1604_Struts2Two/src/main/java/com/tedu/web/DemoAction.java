package com.tedu.web;

@Controller
public class DemoAction {
	public String execute(){
		System.out.println("Demo");
		return "error";
	}
}
