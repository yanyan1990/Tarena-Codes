package demo;

import java.io.PrintWriter;

public class DemoServlet extends HttpServlet{

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
		throws ServletException,IOException{
		res.setContentType("text/html;charset=UTF-8");
		res.setCharacterEncoding("utf-8");
		PrintWriter out = res.getWriter();
		out.println("<html><body>Hi</body></html>");
		out.close();
	}
}
