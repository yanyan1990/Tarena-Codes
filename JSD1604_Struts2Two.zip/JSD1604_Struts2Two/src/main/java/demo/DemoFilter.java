package demo;

import java.io.IOException;
import java.io.PrintWriter;

public class DemoFilter implements Filter{

	public void destroy(){
		
	}
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException{
		HttpServletResponse response = (HttpServletResponse) res;
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write("<html><body>Filter</body></html>");
		out.close();
	}
	public void init(FilterConfig config) throws ServletException{
		
	}
}
