package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import annotation.Hotel;
import annotation.Manager;
import annotation.Restaurant;
import annotation.Student;

public class TestCase2 {

	/*
	 * �������ɨ��
	 */
	@Test
	public void test1(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Student stu = (Student) ac.getBean("stu",Student.class);
		System.out.println(stu);
	}
	
	/*
	 * ����������
	 */
	@Test
	public void test2(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Student stu = (Student)ac.getBean("stu",Student.class);
		Student stu2 = (Student)ac.getBean("stu",Student.class);
		System.out.println(stu == stu2);
	}
	
	/*
	 * �����ӳټ���
	 */
	@Test
	public void test3(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Student stu = (Student)ac.getBean("stu",Student.class);
		Student stu2 = (Student)ac.getBean("stu",Student.class);
		System.out.println(stu == stu2);
	}
	
	/*
	 * ��������������صķ���
	 */
	public void test4(){
		AbstractApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Student stu = (Student)ac.getBean("stu");
		System.out.println(stu);
		ac.close();
	}
	
	/*
	 * ����@Autowired�����ע��
	 */
	@Test
	public void test5(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Restaurant rest = (Restaurant)ac.getBean("rest");
		System.out.println(rest);
		Hotel hotel = (Hotel)ac.getBean("hotel");
		System.out.println(hotel);
	}
	
	/*
	 * ����@Resource�����ע��
	 */
	@Test
	public void test6(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Manager mg = (Manager)ac.getBean("manager");
		System.out.println(mg);
	}
	
	/*
	 * ����@Value
	 */
	@Test
	public void test7(){
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"app.xml");
		Manager mg = (Manager)ac.getBean("manager");
		System.out.println(mg);
	}
}
