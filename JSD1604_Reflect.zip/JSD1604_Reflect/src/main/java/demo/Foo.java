package demo;

public class Foo {

	@MyLove
	public void f(){
		System.out.println("f");
	}
	public void test(){
		System.out.println("Hello");
	}
	public void test2(){
		System.out.println("test2");
	}
}
