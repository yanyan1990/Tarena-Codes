package day02;
/**
 * ��г����
 * @author Administrator
 *
 */
public class Test03 {

	public static void main(String[] args) {

		String regex = "(wqnmlgb|cnm|sb|2b|nc|tmd|cby|djb)";
		String message = "wqnmlgb!";
		message = message.replaceAll(regex, "****");
		System.out.println(message);
	}

}
