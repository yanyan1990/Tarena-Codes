package day02;

public class Test04 {

	public static void main(String[] args){
		Test04 t = new Test04();
		t.toString();
	}
}
