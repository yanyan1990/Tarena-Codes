package day01;
/**
 * String trim()
 * ȥ����ǰ�ַ������ߵĿհ��ַ�
 * @author Administrator
 *
 */
public class StringDemo4 {

	public static void main(String[] args){
		String str ="  hello       ";
		String trim = str.trim();
		System.out.println(str);
		System.out.println(trim);
	}
}
